# SkinCancerDetector
A web app for classifying a skin lesion as Malignant or Benign.

The web app is deployed on: https://rishabh5752-skin-cancer-detector.hf.space/ ,
through Huggingface Spaces.
